/**
 * Kit de seguimiento de clientes · EOS Studio (eosstudio.es)
 *
 * Añade el menú «Seguimiento EOS» a la hoja:
 *   · Enviarme el resumen ahora      → correo con los seguimientos de hoy y atrasados.
 *   · Activar aviso diario           → ese resumen llega solo cada mañana.
 *   · Enviar seguimientos de hoy     → manda el correo de la fase a los clientes marcados
 *                                      con «Seguimiento automático: Sí» (si lo activas en Ajustes).
 *   · Desactivar aviso diario
 *
 * Gratuito y sin servidores: funciona dentro de tu cuenta de Google. Los correos salen
 * desde tu Gmail. Límite de Gmail en cuentas gratuitas: unos 100 destinatarios al día.
 */

const HOJA = 'Seguimiento';
const COL = {
  cliente: 'Cliente', empresa: 'Empresa', correo: 'Correo', fase: 'Fase', ultimo: 'Último contacto',
  proximo: 'Próximo seguimiento', estado: 'Estado', responsable: 'Responsable', auto: 'Seguimiento automático',
};

function onOpen() {
  SpreadsheetApp.getUi().createMenu('Seguimiento EOS')
    .addItem('Enviarme el resumen ahora', 'enviarResumenAhora')
    .addItem('Activar aviso diario', 'activarAvisoDiario')
    .addSeparator()
    .addItem('Enviar seguimientos de hoy', 'enviarSeguimientosAhora')
    .addSeparator()
    .addItem('Desactivar aviso diario', 'desactivarAvisoDiario')
    .addToUi();
}

/* ───────────────────────── Menú */

function enviarResumenAhora() {
  const n = avisoDiario_({ manual: true, enviarAutomaticos: false });
  SpreadsheetApp.getActive().toast(n ? `Resumen enviado: ${n} seguimientos pendientes.` : 'Hoy no tienes seguimientos pendientes.', 'Seguimiento EOS', 6);
}

function enviarSeguimientosAhora() {
  const ui = SpreadsheetApp.getUi();
  if (ajuste_('Enviar seguimientos automáticos') !== 'Sí') {
    ui.alert('Los envíos automáticos están desactivados', 'Para activarlos, pon «Sí» en Ajustes → «Enviar seguimientos automáticos».', ui.ButtonSet.OK);
    return;
  }
  const r = ui.alert('Enviar seguimientos de hoy', 'Se enviará el correo de su fase a los clientes con «Seguimiento automático: Sí» cuyo seguimiento toca hoy o está atrasado. ¿Continuar?', ui.ButtonSet.YES_NO);
  if (r !== ui.Button.YES) return;
  const enviados = enviarAutomaticos_();
  ui.alert('Hecho', `Correos enviados: ${enviados.length}. Los tienes anotados en la hoja «Registro».`, ui.ButtonSet.OK);
}

function activarAvisoDiario() {
  desactivarAvisoDiario_(true);
  const hora = Math.min(23, Math.max(0, Number(ajuste_('Hora del aviso diario (0-23)')) || 8));
  ScriptApp.newTrigger('avisoDiario').timeBased().everyDays(1).atHour(hora).create();
  SpreadsheetApp.getUi().alert('Aviso diario activado', `Cada día, hacia las ${hora}:00, recibirás un correo con los seguimientos que tocan.`, SpreadsheetApp.getUi().ButtonSet.OK);
}

function desactivarAvisoDiario() { desactivarAvisoDiario_(false); }

function desactivarAvisoDiario_(silencio) {
  ScriptApp.getProjectTriggers().filter((t) => t.getHandlerFunction() === 'avisoDiario').forEach((t) => ScriptApp.deleteTrigger(t));
  if (!silencio) SpreadsheetApp.getActive().toast('Aviso diario desactivado.', 'Seguimiento EOS', 5);
}

/* ───────────────────────── Tarea diaria (la lanza el activador) */

function avisoDiario() { avisoDiario_({ manual: false, enviarAutomaticos: true }); }

function avisoDiario_(op) {
  const enviados = op.enviarAutomaticos && ajuste_('Enviar seguimientos automáticos') === 'Sí' ? enviarAutomaticos_() : [];
  SpreadsheetApp.flush();
  const pendientes = filas_().filter((f) => f.estado === 'Hoy' || f.estado === 'Atrasado');
  if (!pendientes.length && !enviados.length) {
    if (op.manual) return 0;
    return 0; // Sin seguimientos: no se manda correo para no llenar tu bandeja.
  }
  const para = String(ajuste_('Correo para el resumen diario') || '').trim() || Session.getEffectiveUser().getEmail();
  const url = SpreadsheetApp.getActive().getUrl();
  const fila = (f) => `<tr>
      <td style="padding:6px 10px;border-bottom:1px solid #E6DED2;"><b>${esc_(f.cliente)}</b><br><span style="color:#7A6E6A;">${esc_(f.empresa || '')}</span></td>
      <td style="padding:6px 10px;border-bottom:1px solid #E6DED2;">${esc_(f.fase)}</td>
      <td style="padding:6px 10px;border-bottom:1px solid #E6DED2;color:${f.estado === 'Atrasado' ? '#B3261E' : '#A8431C'};"><b>${f.estado}</b><br>${fecha_(f.proximo)}</td>
      <td style="padding:6px 10px;border-bottom:1px solid #E6DED2;">${esc_(f.responsable || '')}</td></tr>`;
  const html = `<div style="font-family:Arial,sans-serif;font-size:14px;color:#1B1412;">
    <p style="font-family:Georgia,serif;font-size:20px;margin:0 0 6px;">Tus seguimientos de hoy</p>
    <p style="color:#4A3F3B;margin:0 0 14px;">${pendientes.length} pendientes${enviados.length ? ` · ${enviados.length} correos automáticos enviados` : ''}.</p>
    ${pendientes.length ? `<table cellpadding="0" cellspacing="0" style="border-collapse:collapse;width:100%;max-width:640px;">
      <tr style="background:#1D1716;color:#fff;"><th align="left" style="padding:6px 10px;">Cliente</th><th align="left" style="padding:6px 10px;">Fase</th><th align="left" style="padding:6px 10px;">Estado</th><th align="left" style="padding:6px 10px;">Responsable</th></tr>
      ${pendientes.map(fila).join('')}</table>` : ''}
    ${enviados.length ? `<p style="margin:16px 0 4px;"><b>Enviados automáticamente:</b> ${enviados.map(esc_).join(', ')}</p>` : ''}
    <p style="margin:18px 0 0;"><a href="${url}" style="color:#A8431C;">Abrir la hoja de seguimiento</a></p>
    <p style="color:#7A6E6A;font-size:12px;margin:18px 0 0;">Kit de seguimiento de clientes · EOS Studio · eosstudio.es</p></div>`;
  MailApp.sendEmail({ to: para, subject: `Seguimientos de hoy: ${pendientes.length} pendientes`, htmlBody: html, name: 'Seguimiento EOS' });
  return pendientes.length;
}

/* ───────────────────────── Envío de seguimientos */

function enviarAutomaticos_() {
  const hoja = SpreadsheetApp.getActive().getSheetByName(HOJA);
  const cab = cabeceras_(hoja);
  const max = Number(ajuste_('Máximo de correos automáticos al día')) || 20;
  const plantillas = plantillas_();
  const fases = fasesPlantilla_();
  const yo = { mi_nombre: String(ajuste_('Tu nombre (firma de los correos)') || ''), mi_empresa: String(ajuste_('Tu empresa') || '') };
  const hoy = hoy_();
  const enviados = [];
  for (const f of filas_()) {
    if (enviados.length >= max) break;
    if (f.auto !== 'Sí' || !(f.proximo instanceof Date) || dia_(f.proximo) > hoy) continue;
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(f.correo || '')) { registrar_(f, '', 'Sin correo válido: no se envía'); continue; }
    const p = plantillas[fases[f.fase]];
    if (!p) { registrar_(f, fases[f.fase] || '', 'La fase no tiene plantilla: no se envía'); continue; }
    const vars = { ...yo, nombre: String(f.cliente).split(' ')[0], empresa: f.empresa || '' };
    const rellenar = (t) => String(t).replace(/\{(\w+)\}/g, (m, k) => (k in vars ? vars[k] : m));
    try {
      GmailApp.sendEmail(f.correo, rellenar(p.asunto), rellenar(p.mensaje), { name: yo.mi_nombre || undefined });
      hoja.getRange(f.fila, cab[COL.ultimo]).setValue(new Date(hoy));
      registrar_(f, fases[f.fase], 'Enviado');
      enviados.push(f.cliente);
    } catch (e) {
      registrar_(f, fases[f.fase], 'Error: ' + e.message);
    }
  }
  return enviados;
}

/* ───────────────────────── Lectura de la hoja */

function filas_() {
  const hoja = SpreadsheetApp.getActive().getSheetByName(HOJA);
  const cab = cabeceras_(hoja);
  const datos = hoja.getDataRange().getValues();
  const out = [];
  for (let i = 1; i < datos.length; i++) {
    const r = datos[i];
    const v = (k) => r[cab[COL[k]] - 1];
    if (!v('cliente')) continue;
    out.push({ fila: i + 1, cliente: v('cliente'), empresa: v('empresa'), correo: String(v('correo') || '').trim(), fase: v('fase'),
      proximo: v('proximo'), estado: v('estado'), responsable: v('responsable'), auto: v('auto') });
  }
  return out;
}

function cabeceras_(hoja) {
  const fila = hoja.getRange(1, 1, 1, hoja.getLastColumn()).getValues()[0];
  const cab = {};
  fila.forEach((h, i) => { cab[String(h).trim()] = i + 1; });
  for (const k in COL) if (!cab[COL[k]]) throw new Error(`Falta la columna «${COL[k]}» en la hoja ${HOJA}.`);
  return cab;
}

function ajuste_(nombre) {
  const datos = SpreadsheetApp.getActive().getSheetByName('Ajustes').getDataRange().getValues();
  const f = datos.find((r) => String(r[0]).trim() === nombre);
  return f ? f[1] : '';
}

function fasesPlantilla_() {
  const datos = SpreadsheetApp.getActive().getSheetByName('Fases').getDataRange().getValues();
  const out = {};
  datos.slice(1).forEach((r) => { if (r[0]) out[r[0]] = r[2]; });
  return out;
}

function plantillas_() {
  const datos = SpreadsheetApp.getActive().getSheetByName('Plantillas').getDataRange().getValues();
  const out = {};
  datos.slice(1).forEach((r) => { if (r[0] && r[1] && r[2]) out[r[0]] = { asunto: r[1], mensaje: r[2] }; });
  return out;
}

function registrar_(f, plantilla, resultado) {
  SpreadsheetApp.getActive().getSheetByName('Registro').appendRow([new Date(), f.cliente, f.correo, plantilla, resultado]);
}

/* ───────────────────────── Utilidades */

function hoy_() { return dia_(new Date()); }
function dia_(d) { const x = new Date(d); x.setHours(0, 0, 0, 0); return x.getTime(); }
function fecha_(d) { return d instanceof Date ? Utilities.formatDate(d, Session.getScriptTimeZone(), 'dd/MM/yyyy') : ''; }
function esc_(s) { return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
